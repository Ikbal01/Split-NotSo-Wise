package bg.sofia.uni.fmi.mjt.split.wise;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class User {
    private String name;
    private String username;
    private String password;
    private Socket socket;
    private BufferedReader reader;
    private PrintWriter writer;

    private Map<User, Double> friends;
    private Map<String, Group> groups;

    private StringBuilder friendsNotifications;
    private StringBuilder groupsNotifications;
    private StringBuilder messages;

    public User(String name, String username, String password) {
        this.name = name;
        this.username = username;
        this.password = password;

        friends = new HashMap<>();
        groups = new HashMap<>();
        friendsNotifications = new StringBuilder();
        groupsNotifications = new StringBuilder();
        messages = new StringBuilder();
    }

    public String getPassword() {
        return password;
    }

    public void addFriend(User friend) {
        String message;

        if (friend == null) {
            message = "No such user !\n";
        } else if (friends.containsKey(friend)) {
            message = String.format("%s is already added to friend list\n", friend.getUsername());
        } else {
            friends.put(friend, 0.0);

            message = String.format("%s is successfully added to friend list\n", friend.getUsername());
        }

        sendActivityMessage(message);
    }

    public void addToGroup(Group group) {
        groups.put(group.getName(), group);
    }

    public void createGroup(String groupName, ArrayList<User> members) {
        new Group(groupName, members, this);
    }

    public void split(User friend, double amount, String reasonForPayment) {
        if (friend == null) {
            sendActivityMessage("No such registered user!");
        } else if (friends.containsKey(friend)) {
            double newAmount = friends.get(friend) + (amount / 2);

            friends.put(friend, newAmount);
            sendActivityMessage(String.format("You split %f lv between you and %s.\n", amount, friend.getName()));

            friend.friends.put(this, -newAmount);
            friend.sendActivityMessage(String.format("%s split %f lv between you and him/her.\n", this.name, amount));

            String youOweMessage = String.format("Current status: You owe %f lv.\n", newAmount);
            if (newAmount > 0) {
                sendActivityMessage(String.format("Current status: %s owes you %f lv.\n", friend.getName(), newAmount));
                friend.sendActivityMessage(youOweMessage);
            } else {
                sendActivityMessage(youOweMessage);
                friend.sendActivityMessage(String.format("Current status: %s owes you %f lv.\n", this.name, newAmount));
            }
        } else {
            sendActivityMessage("You do not have such a friend!\n");
        }
    }

    public void splitGroup(String groupName, double amount, String reasonForPayment) {
        if (groups.containsKey(groupName)) {
            groups.get(groupName).split(this, amount, reasonForPayment);
        } else {
            sendActivityMessage("You are not a member of this group!\n");
        }
    }

    public void status() {
        StringBuilder status = new StringBuilder();

        status.append("Friends:\n");

        String friendsStatus = friendsStatus();
        if (friendsStatus != null) {
            status.append(friendsStatus);
        } else {
            status.append("You have no obligations.\n");
        }

        status.append("Groups:\n");

        String groupsStatus = groupsStatus();
        if (groupsStatus != null) {
            status.append(groupsStatus);
        } else {
            status.append("You have no obligations.\n");
        }

        sendActivityMessage(status.toString());
    }

    private String friendsStatus() {
        StringBuilder status = new StringBuilder();

        for (Map.Entry<User, Double> friend : friends.entrySet()) {
            if (friend.getValue() > 0) {
                status.append(String.format("* %s (%s): Owes you %f lv.\n",
                        friend.getKey().getName(), friend.getKey().getUsername(), friend.getValue()));
            } else if (friend.getValue() < 0) {
                status.append(String.format("* %s (%s): You owe %f lv.\n",
                        friend.getKey().getName(), friend.getKey().getUsername(), -friend.getValue()));
            }
        }

        return status.length() > 0 ? status.toString() : null;
    }

    private String groupsStatus() {
        StringBuilder status = new StringBuilder();

        for (Group group : groups.values()) {
            status.append(group.getStatus(this));
        }

        return status.length() > 0 ? status.toString() : null;
    }

    public void friendPayed(double amount, User friend) {
        if (friend == null) {
            sendActivityMessage("No such user !\n");
        } else if (friends.containsKey(friend)) {
            double newAmount = friends.get(friend) - amount;

            friends.put(friend, newAmount);
            sendActivityMessage(String.format("%s (%s) payed you %f lv.\n",
                    friend.getName(), friend.getUsername(), amount));

            friend.friends.put(this, -newAmount);
            friend.sendActivityMessage(String.format("%s (%s) approved your payment %f lv\n",
                    name, username, amount));
        } else {
            sendActivityMessage("You do not have such a friend!\n");
        }
    }

    public void groupFriendPayed(double amount, User user, String groupName) {
        if (groups.containsKey(groupName)) {
            if (user != null) {
                groups.get(groupName).pay(user, this, amount);
            } else {
                sendActivityMessage("No such user !\n");
            }
        } else {
            sendActivityMessage("There is not such a group!\n");
        }
    }

    public void sendFriend(User friend, String message) {
        if (friend != null) {
            if (friends.containsKey(friend)) {
                friend.sendMessage(this, message);
            } else {
                sendActivityMessage(String.format("You have no friend named %s!\n", friend.getName()));
            }
        } else {
            sendActivityMessage("No such user !\n");
        }
    }

    public void sendAllFriends(String message) {
        for (User friend : friends.keySet()) {
            friend.sendMessage(this, message);
        }
    }

    public void sendGroup(String groupName, String message) {
        if (groups.containsKey(groupName)) {
            for (User member : groups.get(groupName).getMemebers()) {
                member.sendMessage(this, message);
            }
        } else {
            sendActivityMessage("You are not a member of this group!\n");
        }
    }

    public void sendFriendsNotifications(String message) {
        if (socket == null) {
            friendsNotifications.append(message).append("\n");
        } else {
            writer.println(message);
        }
    }

    public void sendGroupsNotifications(String message) {
        if (socket == null) {
            groupsNotifications.append(message).append("\n");
        } else {
            writer.println(message);
        }
    }

    public void sendActivityMessage(String message) {
        try {
            writer.println(message);
        } catch (Exception e) {
            System.out.println("An error occurred while sending the activity message!\n");
        }
    }

    public void sendMessage(User from, String message) {
        String resultMessage = String.format("%s (%s): %s\n",
                from.getName(), from.getUsername(), message);

        if (socket == null) {
            messages.append(resultMessage);
        } else {
            writer.print(resultMessage);
        }
    }

    public void readNotifications() {
        StringBuilder notifiaction = new StringBuilder();

        notifiaction.append("*** Notifications ***\n");
        notifiaction.append("Friends:\n");
        notifiaction.append(readFriendsNotifications());
        notifiaction.append("Groups:\n");
        notifiaction.append(readGroupsNotifications());
        notifiaction.append("Messages:\n");
        notifiaction.append(readMessages());

        writer.println(notifiaction.toString());
    }

    private String readFriendsNotifications() {
        String notifications = friendsNotifications.toString();
        friendsNotifications.setLength(0);
        return notifications;
    }

    private String readGroupsNotifications() {
        String notifications = groupsNotifications.toString();
        groupsNotifications.setLength(0);
        return notifications;
    }

    private String readMessages() {
        String messages = this.messages.toString();
        this.messages.setLength(0);
        return messages;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }

    public void setReader(BufferedReader reader) {
        this.reader = reader;
    }

    public void setWriter(PrintWriter writer) {
        this.writer = writer;
    }

    public Socket getSocket() {
        return socket;
    }

    public PrintWriter getWriter() {
        return writer;
    }

    public BufferedReader getReader() {
        return reader;
    }
}
