package bg.sofia.uni.fmi.mjt.split.wise;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class SplitNotSoWiseServer {

    private static final int SERVER_PORT = 8080;

    private Map<String, User> users;

    public static void main(String[] args) {
        SplitNotSoWiseServer server = new SplitNotSoWiseServer();
        server.run();
    }

    public void run() {
        try (ServerSocket serverSocket = new ServerSocket(SERVER_PORT)) {

            users = new HashMap<>();
            System.out.println("Server started");

            while (true) {
                Socket socket = serverSocket.accept();

                new Thread(new ClientRequestHandler(this, socket)).start();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void readRegisteredUsers() {
        users = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("resources/username_pass.txt"))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(" ");

            }
        } catch (IOException e) {

        }
    }

    public Map<String, User> getUsers() {
        return users;
    }

    public User getUser(String username) {
        return users.get(username);
    }
}
